// services/user-service/src/types.ts
export interface User {
  id: string;
  name: string;
  email: string;
}