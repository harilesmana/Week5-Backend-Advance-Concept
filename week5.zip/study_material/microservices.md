# Microservices

## 1. Apa itu Microservices?
Microservices adalah pendekatan arsitektur perangkat lunak yang membagi aplikasi menjadi serangkaian layanan kecil, mandiri, dan terdistribusi yang saling berinteraksi melalui API. Setiap layanan berfokus pada satu domain atau bisnis fungsional tertentu dan memiliki database dan pengelolaannya sendiri. Microservices memungkinkan pengembangan aplikasi yang lebih terdistribusi, skalabel, dan lebih mudah untuk dimodifikasi atau ditingkatkan.

Ciri-ciri Microservices:

- **Modularitas**: Setiap layanan menangani satu domain fungsional yang terpisah.
- **Independensi**: Setiap layanan dapat dikembangkan, diuji, dideploy, dan diskalakan secara independen.
- **Komunikasi Antar Layanan**: Microservices berkomunikasi melalui API (biasanya menggunakan HTTP, REST, gRPC, atau message queues).
- **Pengelolaan Data Mandiri**: Setiap microservice biasanya memiliki database sendiri (misalnya, database SQL atau NoSQL).

## 2. Keuntungan Menggunakan Microservices
Beberapa alasan utama untuk menggunakan arsitektur microservices dalam pengembangan aplikasi:

### A. Skalabilitas
- Layanan dapat diskalakan secara independen. Jika satu layanan lebih banyak digunakan daripada yang lain, hanya layanan tersebut yang dapat diskalakan tanpa mempengaruhi keseluruhan aplikasi.

### B. Peningkatan Kecepatan Pengembangan
- Pengembang dapat fokus pada bagian kecil dari aplikasi tanpa harus mempengaruhi bagian lain.
- Memungkinkan tim yang lebih kecil dan lebih terfokus pada satu layanan.w

### C. Kemudahan Pembaruan dan Pengelolaan
- Setiap layanan dapat diperbarui secara independen tanpa mempengaruhi aplikasi secara keseluruhan.
- Pembaruan atau perbaikan dapat dilakukan pada satu layanan tanpa harus menghentikan layanan lainnya.

### D. Ketahanan dan Toleransi Kesalahan
- Jika satu layanan gagal, sistem secara keseluruhan tidak akan terpengaruh.
- Pengelolaan kegagalan lebih mudah, dengan adanya fallback atau retry pada komunikasi antar layanan.

### E. Teknologi yang Beragam
- Microservices memungkinkan penggunaan berbagai teknologi, database, dan framework yang berbeda di setiap layanan sesuai dengan kebutuhan fungsionalnya.

## 3. Tantangan dalam Microservices

Meskipun microservices menawarkan banyak keuntungan, ada beberapa tantangan yang perlu dipertimbangkan saat merancang dan mengimplementasikan sistem berbasis microservices.

### A. Kompleksitas dalam Manajemen Layanan
- Dengan banyaknya layanan yang terdistribusi, pengelolaan sistem menjadi lebih kompleks, terutama dalam hal monitoring, logging, dan troubleshooting

### B. Komunikasi Antar Layanan
- Komunikasi antar layanan sering kali membutuhkan mekanisme yang tepat untuk memastikan keandalan, kecepatan, dan konsistensi data (misalnya, synchronous vs asynchronous).

### C. Konsistensi Data
Mempertahankan konsistensi data di seluruh layanan menjadi tantangan, terutama dalam aplikasi yang membutuhkan transaksi yang terdistribusi (misalnya, menggunakan teknik seperti Event Sourcing atau Saga Pattern).

### D. Pengelolaan Infrastruktur
Mikroservis memerlukan orkestrasi yang lebih baik, misalnya menggunakan Docker untuk containerization dan Kubernetes untuk orchestrasi dan manajemen kontainer.

## 4. Arsitektur Microservices
Arsitektur microservices melibatkan beberapa komponen yang saling berinteraksi. Berikut adalah gambaran umum dari arsitektur microservices yang sederhana:

### 4.1. Komponen Utama dalam Arsitektur Microservices:

- API Gateway:

    - API Gateway bertindak sebagai pintu masuk utama untuk aplikasi, yang mengarahkan permintaan ke layanan yang tepat.
    - Selain routing, API Gateway juga bisa melakukan otentikasi, otorisasi, rate-limiting, caching, dan logging.

- Microservices:

    - Setiap layanan menangani satu tanggung jawab atau domain bisnis tertentu.
    - Setiap microservice memiliki database sendiri dan dikelola secara independen.

- Database Per Layanan:

    - Setiap microservice memiliki pengelolaan database terpisah yang sesuai dengan fungsinya.
    - Misalnya, User Service menggunakan database SQL, sedangkan Order Service bisa menggunakan database NoSQL.


- Message Queue (Opsional):

    - Microservices sering kali berkomunikasi menggunakan message brokers seperti RabbitMQ, Apache Kafka, atau NATS, untuk pengolahan pesan secara asinkron dan mengurangi ketergantungan langsung antar layanan.


### 4.2. Diagram Arsitektur Microservices
```js
                      +------------------+
                      |   API Gateway    |
                      | (Routing Layer)  |
                      +------------------+
                               |
               +----------------------------------+
               |                                  |
   +-------------------+                 +-------------------+
   |  User Service     |                 |   Order Service   |
   |  (Microservice)   |                 |  (Microservice)   |
   +-------------------+                 +-------------------+
         |                                  |
    +------------+                     +------------+
    |  Database  |                     |  Database  |
    |  (User DB) |                     | (Order DB) |
    +------------+                     +------------+

```

Penjelasan Komponen:
- API Gateway bertanggung jawab untuk menangani semua permintaan dan mendistribusikannya ke layanan yang sesuai (misalnya, User Service atau Order Service).
- Microservices adalah layanan independen yang menangani fungsionalitas tertentu. Masing-masing layanan memiliki database terpisah dan berkomunikasi melalui API atau pesan.
- Database Per Layanan: Setiap layanan memiliki database terpisah, memastikan bahwa satu layanan tidak mengganggu data layanan lain.

## 5.  Pola Desain Microservices
Ada beberapa pola desain dan prinsip yang biasa digunakan dalam pengembangan microservices:

### 5.1. Single Responsibility Principle
- Setiap microservice harus memiliki satu tanggung jawab atau fungsionalitas yang jelas, misalnya, User Service hanya menangani manajemen pengguna, sedangkan Order Service hanya menangani pesanan.

### 5.2. API First Design
- Mendesain API sebelum implementasi kode untuk memastikan bahwa komunikasi antar microservices berjalan lancar.
- Pendekatan ini sangat penting untuk standar komunikasi dan interaksi antar layanan.

### 5.3. Database Per Service
- Setiap microservice memiliki database sendiri untuk memastikan bahwa data dikelola secara mandiri tanpa saling bergantung.

### 5.4. Event-Driven Architecture
- Penggunaan event-driven architecture dapat mengurangi keterikatan antar layanan.
- Layanan dapat berkomunikasi dengan event bus atau message queue untuk mengirimkan informasi secara asinkron.

### 5.5. Saga Pattern
- Digunakan untuk mengelola transaksi terdistribusi. Misalnya, jika beberapa microservices perlu melakukan beberapa operasi dalam satu transaksi, Saga Pattern akan memastikan bahwa transaksi tersebut dikelola dengan benar dan menghindari data yang tidak konsisten.

## 6. Implementasi Microservices
Berikut adalah langkah-langkah umum dalam mengimplementasikan microservices:

**Langkah 1**: Desain dan Pembagian Layanan
- Tentukan domain bisnis yang akan dipisah menjadi layanan terpisah (misalnya, User Service, Order Service, Payment Service).

**Langkah 2**: Pilih Teknologi yang Tepat
- Pilih teknologi yang tepat untuk setiap layanan, seperti database, bahasa pemrograman, framework, dan teknologi komunikasi antar layanan.

**Langkah 3**: Pengelolaan Database
- Tentukan apakah setiap layanan akan menggunakan database terpisah atau akan berbagi database yang sama (biasanya disarankan menggunakan database terpisah untuk menghindari ketergantungan).

**Langkah 4**: Kembangkan API
- Kembangkan API untuk komunikasi antar layanan (bisa menggunakan REST, gRPC, atau GraphQL).

**Langkah 5**: Orkestrasi dan Deployment
- Gunakan Docker dan Kubernetes untuk melakukan containerization dan orchestration layanan-layanan tersebut.

**Langkah 6**: Monitoring dan Logging
- Gunakan tools seperti Prometheus, Grafana, atau ELK Stack untuk monitoring dan logging di seluruh layanan microservices.