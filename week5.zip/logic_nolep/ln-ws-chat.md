# Logic Nolep ( Chat Room )
pada logic nolep kali ini kalian akan di berikan tugas untuk membuat chat platform dengan persyaratan tertentu
persyaratanya sebagai berikut:

1. aplikasi harus di buat menggunakan stack Bun + Elysia / hono + drizzle + EJS
2. dalam aplikasi chat tersebut harus dibuat menggunakan websocket
3. didalam aplikasi tersebut harus bisa create account, join chat, and kirim pesan
4. user bisa membuat chat room sendiri dan mendelete chat room yang di buat
5. bikin interface untuk testing aplikasi messaging platform dari persyaratan 3 dan 4 menggunakan EJS

Poin Bonus: 
1. User bisa mengubah / mengedit dan menghapus pesan yang sudah dia kirim


pada ln kali ini kalian bisa menggunakan materail yg sudah di pelajari sebelumnya, tinggal menambahkan interface dengan ejs dan menambahkan persyaratan yang belum di penuhi pada ln kali ini

